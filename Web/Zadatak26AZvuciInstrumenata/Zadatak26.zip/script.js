var piano = new Audio('audio/klavir.wav');
var trumpet = new Audio('audio/truba.wav');
var harmonica = new Audio('audio/harmonika.wav');
var drums = new Audio('audio/bubanj.wav');
var flute = new Audio('audio/frula.wav');
var guitar = new Audio('audio/gitara.wav');

function playPiano() {
	piano.play();
}
function playTrumpet() {
	trumpet.play();
}
function playHarmonica() {
	harmonica.play();
}
function playDrums() {
	drums.play();
}
function playFlute() {
	flute.play();
}
function playGuitar() {
	guitar.play();
}
