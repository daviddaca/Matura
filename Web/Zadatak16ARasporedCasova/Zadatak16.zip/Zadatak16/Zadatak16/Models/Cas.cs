﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Zadatak16.Models
{
    public class Cas
    {
        public int Rbr { get; set; }
        public string Predmet { get; set; }
        public string DanUNedelji { get; set; }
    }
}