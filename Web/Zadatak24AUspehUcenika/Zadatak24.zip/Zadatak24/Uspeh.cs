﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Zadatak24
{
    public class Uspeh
    {
        public int Razred { get; set; }
        public int Nedovoljan { get; set; }
        public int Dovoljan { get; set; }
        public int Dobar { get; set; }
        public int Vrlodobar { get; set; }
        public int Odlican { get; set; }
        public double ProsecnaOcena { get; set; }

    }
}