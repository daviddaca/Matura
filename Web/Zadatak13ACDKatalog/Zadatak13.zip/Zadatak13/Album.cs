﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Zadatak13
{
    public class Album
    {
        public string Izvodjac { get; set; }
        public string Naziv { get; set; }
        public string Zanr { get; set; }
        public int GodinaIzdanja { get; set; }
        public string IzdavackaKuca { get; set; }
        public string Slika { get; set; }
    }
}